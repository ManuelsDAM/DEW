function diAlgo() {
    alert("Hola");
}

diAlgo();
